
import React from 'react';
import { Statement, StatementCategory } from '../types';
import Card from './shared/Card';

interface StatementSelectorProps {
  categories: StatementCategory[];
  selectedStatementIds: Set<string>;
  onStatementToggle: (statementId: string) => void;
}

const StatementSelector: React.FC<StatementSelectorProps> = ({ categories, selectedStatementIds, onStatementToggle }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {categories.map((category) => (
        <Card key={category.id} title={category.title} className={`${category.color}`} borderColor={category.borderColor}>
          <ul className="space-y-3">
            {category.statements.map((statement: Statement) => (
              <li key={statement.id} className="flex items-start">
                <input
                  type="checkbox"
                  id={`statement-${statement.id}`}
                  checked={selectedStatementIds.has(statement.id)}
                  onChange={() => onStatementToggle(statement.id)}
                  className="mt-1 mr-2 h-5 w-5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500_disabled_form-checkbox"
                />
                <label htmlFor={`statement-${statement.id}`} className="text-slate-700 text-sm leading-relaxed">
                  {statement.text}
                </label>
              </li>
            ))}
          </ul>
        </Card>
      ))}
    </div>
  );
};

export default StatementSelector;
