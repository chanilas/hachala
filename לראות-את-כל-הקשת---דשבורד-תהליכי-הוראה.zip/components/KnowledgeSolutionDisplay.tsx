
import React from 'react';
import { KnowledgeSolution, SolutionGroup, SolutionItem } from '../types';
import Card from './shared/Card';

interface KnowledgeSolutionDisplayProps {
  solutions: KnowledgeSolution[];
}

const KnowledgeSolutionDisplay: React.FC<KnowledgeSolutionDisplayProps> = ({ solutions }) => {
  if (solutions.length === 0) {
    return (
      <Card className="bg-white" borderColor="border-slate-300">
        <p className="text-slate-600 text-center py-4">לא זוהו זירות פעולה, או שלא נמצאו פתרונות מתאימים.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      {solutions.map((solution) => (
        <Card key={solution.id} title={solution.title} className={`${solution.color} border-2`} borderColor={solution.borderColor}>
          {solution.solutionGroups.map((group: SolutionGroup) => (
            <div key={group.id} className="mb-6 p-4 border rounded-lg bg-white/50 shadow">
              <h4 className="text-lg font-semibold text-slate-800 mb-3 pb-2 border-b border-slate-300">{group.groupTitle}</h4>
              <ul className="space-y-2">
                {group.items.map((item: SolutionItem) => (
                  <li key={item.id} className="text-slate-700 text-sm leading-relaxed">
                    <span className="font-medium">{item.text}</span>
                    {item.subItems && item.subItems.length > 0 && (
                      <ul className="list-disc list-inside space-y-1 pl-5 mt-1 text-xs">
                        {item.subItems.map((subItem, subIndex) => (
                          <li key={subIndex}>{subItem}</li>
                        ))}
                      </ul>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </Card>
      ))}
    </div>
  );
};

export default KnowledgeSolutionDisplay;
