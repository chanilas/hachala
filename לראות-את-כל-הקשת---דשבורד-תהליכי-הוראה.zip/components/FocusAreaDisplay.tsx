
import React from 'react';
import { WorkArena } from '../types';
import Card from './shared/Card';

interface FocusAreaDisplayProps {
  focusAreas: WorkArena[];
}

const FocusAreaDisplay: React.FC<FocusAreaDisplayProps> = ({ focusAreas }) => {
  if (focusAreas.length === 0) {
    return (
      <Card className="bg-white" borderColor="border-slate-300">
        <p className="text-slate-600 text-center py-4">בחר/י היגדים בשלב 1 כדי לראות זירות פעולה רלוונטיות.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {focusAreas.map((arena) => (
        <Card key={arena.id} title={arena.title} className={`${arena.color}`} borderColor={arena.borderColor}>
          <div>
            <p className="text-md font-semibold text-slate-700 mb-2">זירת פעולה מוצעת להדרכה: <span className="font-normal">{arena.suggestedActionArea}</span></p>
            
            {arena.centralEmphasisDetails.map(detailGroup => (
              <div key={detailGroup.id} className="mb-4 last:mb-0">
                <h4 className="text-lg font-semibold text-slate-800 mb-2 pt-2 border-t border-slate-300">{detailGroup.title}:</h4>
                <ul className="list-disc list-inside space-y-1 pl-4">
                  {detailGroup.points.map((point, index) => (
                    <li key={index} className="text-md text-slate-700">{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
};

export default FocusAreaDisplay;
