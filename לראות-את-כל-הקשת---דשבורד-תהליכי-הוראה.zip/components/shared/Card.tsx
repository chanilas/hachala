
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  titleClassName?: string;
  borderColor?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', title, titleClassName = '', borderColor = 'border-slate-300' }) => {
  return (
    <div className={`bg-white shadow-lg rounded-xl p-6 border-t-4 ${borderColor} ${className}`}>
      {title && (
        <h3 className={`text-xl font-semibold text-slate-700 mb-4 pb-2 border-b ${borderColor} ${titleClassName}`}>
          {title}
        </h3>
      )}
      {children}
    </div>
  );
};

export default Card;
