
import React, { useState, useEffect, useCallback } from 'react';
import { StatementCategory, Statement, WorkArena, KnowledgeSolution } from './types';
import { STATEMENT_CATEGORIES, WORK_ARENAS, KNOWLEDGE_SOLUTIONS, APP_TITLE, APP_SUBTITLE, SECTIONS_TITLES } from './constants';
import StatementSelector from './components/StatementSelector';
import FocusAreaDisplay from './components/FocusAreaDisplay';
import KnowledgeSolutionDisplay from './components/KnowledgeSolutionDisplay';
import Card from './components/shared/Card';

const App: React.FC = () => {
  const [selectedStatementIds, setSelectedStatementIds] = useState<Set<string>>(new Set());
  const [derivedFocusAreas, setDerivedFocusAreas] = useState<WorkArena[]>([]);
  const [derivedKnowledgeSolutions, setDerivedKnowledgeSolutions] = useState<KnowledgeSolution[]>([]);

  const handleStatementToggle = useCallback((statementId: string) => {
    setSelectedStatementIds(prevSelectedIds => {
      const newSelectedIds = new Set(prevSelectedIds);
      if (newSelectedIds.has(statementId)) {
        newSelectedIds.delete(statementId);
      } else {
        newSelectedIds.add(statementId);
      }
      return newSelectedIds;
    });
  }, []);

  useEffect(() => {
    const implicatedCategoryIds = new Set<string>();
    selectedStatementIds.forEach(id => {
      const foundStatement = STATEMENT_CATEGORIES.flatMap(cat => cat.statements).find(stmt => stmt.id === id);
      if (foundStatement) {
        implicatedCategoryIds.add(foundStatement.categoryId);
      }
    });

    const focusAreas = WORK_ARENAS.filter(arena => implicatedCategoryIds.has(arena.statementCategoryId));
    setDerivedFocusAreas(focusAreas);

  }, [selectedStatementIds]);

  useEffect(() => {
    const focusAreaStatementCategoryIds = new Set<string>(derivedFocusAreas.map(area => area.statementCategoryId));
    const solutions = KNOWLEDGE_SOLUTIONS.filter(solution => focusAreaStatementCategoryIds.has(solution.workArenaStatementCategoryId));
    setDerivedKnowledgeSolutions(solutions);
  }, [derivedFocusAreas]);

  const ministryLogoSvg = (
    <svg width="80" height="80" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-75">
      <path d="M60 0L70 15H50L60 0Z" fill="#003876"/>
      <path d="M60 120L70 105H50L60 120Z" fill="#003876"/>
      <path d="M0 60L15 70V50L0 60Z" fill="#003876"/>
      <path d="M120 60L105 70V50L120 60Z" fill="#003876"/>
      <path d="M95 25L85 35H75L95 25Z" fill="#003876"/>
      <path d="M25 95L35 85H45L25 95Z" fill="#003876"/>
      <path d="M25 25L35 35H45L25 25Z" fill="#3C97D3"/>
      <path d="M95 95L85 85H75L95 95Z" fill="#3C97D3"/>
      <circle cx="60" cy="60" r="30" fill="#003876"/>
      <circle cx="60" cy="60" r="20" fill="#FFFFFF"/>
      <path d="M60 45L65 55H55L60 45Z" fill="#003876"/>
    </svg>
  );
  
  const rainbowBanner = (
    <div className="h-2 w-full flex">
      <div className="flex-1 bg-red-500"></div>
      <div className="flex-1 bg-orange-500"></div>
      <div className="flex-1 bg-yellow-400"></div>
      <div className="flex-1 bg-green-500"></div>
      <div className="flex-1 bg-blue-500"></div>
      <div className="flex-1 bg-indigo-500"></div>
      <div className="flex-1 bg-purple-500"></div>
    </div>
  );


  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
       <header className="bg-white shadow-md sticky top-0 z-50">
        {rainbowBanner}
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-right">
            <h1 className="text-3xl font-bold text-sky-700">{APP_TITLE}</h1>
            <p className="text-sm text-slate-600">{APP_SUBTITLE}</p>
          </div>
          <div className="flex-shrink-0">
            {/* Placeholder for a simplified logo or relevant graphic */}
             <img src="https://raw.githubusercontent.com/MoeGovIL/gems-design-system-brand/main/logo/png/color.png" alt="לראות את כל הקשת לוגו" className="h-16 w-auto opacity-80" />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <section id="statements" aria-labelledby="statements-title" className="mb-12">
          <h2 id="statements-title" className="text-2xl font-semibold text-sky-600 mb-2">{SECTIONS_TITLES.statements}</h2>
          <p className="text-slate-600 mb-6">בחר/י את ההיגדים המשקפים אתגרים או תחומים לחיזוק בבית הספר שלך. הבחירות שלך יסייעו בזיהוי זירות פעולה ופתרונות מתאימים.</p>
          <StatementSelector 
            categories={STATEMENT_CATEGORIES}
            selectedStatementIds={selectedStatementIds}
            onStatementToggle={handleStatementToggle}
          />
        </section>

        {selectedStatementIds.size > 0 && (
          <>
            <section id="focus-areas" aria-labelledby="focus-areas-title" className="mb-12">
              <h2 id="focus-areas-title" className="text-2xl font-semibold text-indigo-600 mb-6">{SECTIONS_TITLES.focusAreas}</h2>
              <FocusAreaDisplay focusAreas={derivedFocusAreas} />
            </section>

            {derivedFocusAreas.length > 0 && (
               <section id="solutions" aria-labelledby="solutions-title" className="mb-12">
                <h2 id="solutions-title" className="text-2xl font-semibold text-emerald-600 mb-6">{SECTIONS_TITLES.solutions}</h2>
                <KnowledgeSolutionDisplay solutions={derivedKnowledgeSolutions} />
              </section>
            )}
          </>
        )}

        {selectedStatementIds.size === 0 && (
          <Card className="mt-12 text-center py-10" borderColor="border-slate-300">
            <p className="text-lg text-slate-500">אנא בחר/י היגדים בשלב 1 כדי להתחיל בתהליך.</p>
             <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto mt-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 16V8m0 0L3 4m4 4l4-4m-4 4H3" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 8h10M7 16h10" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 16V8m0 0l4-4m-4 4l-4-4m4 4h4" />
             </svg>
          </Card>
        )}
      </main>
      
      <footer className="bg-slate-800 text-slate-300 py-6 text-center mt-auto">
        <div className="container mx-auto px-4">
          <p>&copy; {new Date().getFullYear()} {APP_TITLE}. פותח בהשראת מסמכי משרד החינוך.</p>
          <p className="text-xs mt-1">יישום זה הינו כלי עזר ואינו מהווה תחליף לייעוץ פדגוגי מקצועי.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
